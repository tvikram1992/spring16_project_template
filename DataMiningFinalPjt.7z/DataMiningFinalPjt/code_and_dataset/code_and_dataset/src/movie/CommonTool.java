package movie;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import movie.model.IHasId;

public class CommonTool
{
    private CommonTool()
    {
        
    }
    
    public static <E extends IHasId> Map<Integer, E> toMap(Collection<E> elements)
    {
        Map<Integer, E> map = new HashMap<>(elements.size());
        for(E element : elements)
        {
            map.put(element.getId(), element);
        }
        return map;
    }
}
