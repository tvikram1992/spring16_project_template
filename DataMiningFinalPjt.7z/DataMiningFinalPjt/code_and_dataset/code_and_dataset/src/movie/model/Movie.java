package movie.model;

import java.util.LinkedList;
import java.util.List;

public class Movie implements IHasId
{
    private int id;
    private String title;
    private long releaseDate;
    private long videoReleaseDate;
    private String imdbURL;
    private final List<Genre> genres = new LinkedList<>();

    public List<Genre> getGenres()
    {
        return genres;
    }

    @Override
    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public long getReleaseDate()
    {
        return releaseDate;
    }

    public void setReleaseDate(long releaseDate)
    {
        this.releaseDate = releaseDate;
    }

    public String getImdbURL()
    {
        return imdbURL;
    }

    public void setImdbURL(String imdbURL)
    {
        this.imdbURL = imdbURL;
    }

    public long getVideoReleaseDate()
    {
        return videoReleaseDate;
    }

    public void setVideoReleaseDate(long videoReleaseDate)
    {
        this.videoReleaseDate = videoReleaseDate;
    }
}
