package movie.model;

public enum Gender
{
    MALE, FEMALE;
}
