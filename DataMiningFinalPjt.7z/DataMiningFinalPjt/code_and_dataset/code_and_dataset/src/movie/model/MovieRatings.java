package movie.model;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * 
 * This class is designed for storing the sparse matrix of user-movie ratings.
 *
 */
public class MovieRatings
{
    private final List<TreeMap<Integer, Rating>> userToRatingMaps = new LinkedList<>();
    private final List<TreeMap<Integer, Rating>> movieToRatingMaps = new LinkedList<>();
    
    /**
     * Get the number of all ratings.
     * @return
     */
    public int size()
    {
        int size = 0;
        for(Map<?, ?> map : userToRatingMaps)
        {
            size += map.size();
        }
        return size;
    }
    
    /**
     * Get the maximum user id.
     * @return
     */
    public int getMaxUserId()
    {
        return movieToRatingMaps.size() - 1;
    }
    
    /**
     * Get the maximum movie id.
     * @return
     */
    public int getMaxMovieId()
    {
        return userToRatingMaps.size() - 1;
    }
    
    /**
     * Set the rating of the specified movie from the given user.
     * @param userId
     * @param movieId
     * @param rating
     */
    public void set(int userId, int movieId, Rating rating)
    {
        this.getUserToRatingMap(movieId).put(userId, rating);
        this.getMovieToRatingMap(userId).put(movieId, rating);
    }
    
    /**
     * Get the rating of the specified movie from the given user.
     * @param userId
     * @param movieId
     * @return
     */
    public Rating get(int userId, int movieId)
    {
        return this.getUserToRatingMap(movieId).get(userId);
    }
    
    /**
     * Get the next rated user id of the given movie.
     * @param userId
     * @param movieId
     * @return
     */
    public int nextUserId(int userId, int movieId)
    {
        Integer nextUserId = this.getUserToRatingMap(movieId).higherKey(userId);
        return (nextUserId == null ? -1 : nextUserId);
    }
    
    /**
     * Get the next rated movie id of the given user.
     * @param userId
     * @param movieId
     * @return
     */
    public int nextMovieId(int userId, int movieId)
    {
        Integer nextMovieId = this.getMovieToRatingMap(userId).higherKey(movieId);
        return (nextMovieId == null ? -1 : nextMovieId);
    }
    
    /**
     * Get the map of user ids to the specific movie ratings.
     * @param movieId
     * @return
     */
    public TreeMap<Integer, Rating> getUserToRatingMap(int movieId)
    {
        while(movieId >= userToRatingMaps.size())
        {
            userToRatingMaps.add(new TreeMap<>());
        }
        return userToRatingMaps.get(movieId);
    }
    
    /**
     * Get the map of movie ids to the specific user ratings.
     * @param userId
     * @return
     */
    public TreeMap<Integer, Rating> getMovieToRatingMap(int userId)
    {
        while(userId >= movieToRatingMaps.size())
        {
            movieToRatingMaps.add(new TreeMap<>());
        }
        return movieToRatingMaps.get(userId);
    }
}
