package movie.model;

public interface IHasId
{
    int getId();
}
