package movie;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import movie.model.Genre;
import movie.model.Movie;
import movie.model.MovieRatings;
import movie.model.Rating;
import movie.model.User;
import movie.prediction.IPredictor;
import movie.prediction.KNNPredictor;

public class MovieStartor
{
    public static void main(String[] strings) throws Exception
    {
        int k = 5;
        int testPercentage = 1;
        
        // Users.
        List<User> users = IOTool.readUsers("ml-100k/u.user");
        Map<Integer, User> userMap = CommonTool.toMap(users);
        
        // Genres.
        List<Genre> genres = IOTool.readGenres("ml-100k/u.genre");
        Map<Integer, Genre> genreMap = CommonTool.toMap(genres);
        
        // Movies.
        List<Movie> movies = IOTool.readMovies("ml-100k/u.item", genreMap);
        Map<Integer, Movie> movieMap = CommonTool.toMap(movies);
        
        // Data.
        MovieRatings baseRatings = IOTool.readMovieRatings("ml-100k/u1.base", userMap, movieMap);
        MovieRatings testRatings = IOTool.readMovieRatings("ml-100k/u1.test", userMap, movieMap);
        
        // Predict.
        IPredictor predictor = new KNNPredictor(userMap, movieMap, k);
//        MovieRatings predictedRatings = predictor.predictRating(baseRatings);
        
        // Calculate accuracy.
        double differenceSum = 0;
        double differenceSquareSum = 0;
        int testSize = testRatings.size();
        int index = 0;
        int percentage = -1;
        
        OutputStream output = new FileOutputStream("result.csv");
        output.write("User Id, Movie Id, Expected Rating, Predicted Rating\n".getBytes());
        testing:
        for(int userId = 0;userId <= testRatings.getMaxUserId();userId++)
        {
            for(int movieId = 0;movieId <= testRatings.getMaxMovieId();movieId++)
            {
                Rating rating = testRatings.get(userId, movieId);
                if(rating == null)
                {
                    continue;
                }
                
                int newPercentage = index*100 / testSize;
                if(newPercentage > percentage)
                {
                    percentage = newPercentage;
                    System.out.println(percentage + "%");
                    if(percentage == testPercentage)
                    {
                        break testing;
                    }
                }
//                Rating predictedRating = predictedRatings.get(userId, movieId);
                int expectedRating = rating.getRating();
                int predictedRating = predictor.predictRating(baseRatings, userId, movieId);
                int difference = expectedRating - predictedRating;
                differenceSum += Math.abs(difference);
                differenceSquareSum += difference * difference;
                index++;
                
                String line = userId + ", " + movieId + ", " + predictedRating
                		+ ", " + expectedRating + "\n";
                output.write(line.getBytes());
            }
        }
        output.close();
        
        double averageDifference = differenceSum / testSize;
        double RMSE = Math.sqrt(differenceSquareSum / testSize);
        System.out.println("Average difference: " + averageDifference);
        System.out.println("RMSE: " + RMSE);
    }
}
