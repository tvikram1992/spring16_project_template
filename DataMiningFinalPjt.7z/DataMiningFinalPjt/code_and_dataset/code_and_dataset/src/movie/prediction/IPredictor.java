package movie.prediction;

import movie.model.MovieRatings;

/**
 * 
 * An interface representing a user-movie rating predictor.
 *
 */
public interface IPredictor
{
    /**
     * Predict every empty slot of the given rating matrix.
     * @param ratings
     * @return
     */
    MovieRatings predictRating(MovieRatings ratings);

    /**
     * Predict the rating of the specified movie from the given user.
     * @param ratings
     * @param userId
     * @param movieId
     * @return
     */
    int predictRating(MovieRatings ratings, int userId, int movieId);
}
