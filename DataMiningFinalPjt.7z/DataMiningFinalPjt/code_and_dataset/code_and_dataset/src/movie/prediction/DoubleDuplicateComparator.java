package movie.prediction;

import java.util.Comparator;

/**
 * 
 * This comparator will take the first double as bigger even the two are the same.
 *
 */
public enum DoubleDuplicateComparator implements Comparator<Double>
{
    INSTANCE;

    @Override
    public int compare(Double double1, Double double2)
    {
        if(double1 >= double2)
        {
            return 1;
        }else
        {
            return -1;
        }
    }
    
}
