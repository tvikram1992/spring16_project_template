package movie.prediction;

import java.util.Map;
import java.util.TreeMap;

import movie.model.Movie;
import movie.model.MovieRatings;
import movie.model.Rating;
import movie.model.User;

/**
 * 
 * This class predicts the ratings according to its k nearest neighbor ratings.
 *
 */
public class KNNPredictor implements IPredictor
{
    private final Map<Integer, User> userMap;
    private final Map<Integer, Movie> movieMap;
    private final int k;
    
    /**
     * Constructor.
     * @param userMap
     * @param movieMap
     * @param k
     */
    public KNNPredictor(Map<Integer, User> userMap, Map<Integer, Movie> movieMap, int k)
    {
        this.userMap = userMap;
        this.movieMap = movieMap;
        this.k = k;
    }

    /**
     * @see movie.prediction.IPredictor#predictRating(movie.model.MovieRatings)
     */
    @Override
    public MovieRatings predictRating(MovieRatings ratings)
    {
        MovieRatings predictedRatings = new MovieRatings();
        for(int userId = 1;userId <= ratings.getMaxUserId();userId++)
        {
            for(int movieId = 1;movieId <= ratings.getMaxMovieId();movieId++)
            {
                if(ratings.get(userId, movieId) == null)
                {
                    Rating rating = new Rating();
                    rating.setRating(this.predictRating(ratings, userId, movieId));
                    rating.setUser(userMap.get(userId));
                    rating.setMovie(movieMap.get(movieId));
                    rating.setTimestamp(System.currentTimeMillis());
                    predictedRatings.set(userId, movieId, rating);
                }
            }
        }
        return predictedRatings;
    }
    
    /**
     * @see movie.prediction.IPredictor#predictRating(movie.model.MovieRatings, int, int)
     */
    @Override
    public int predictRating(MovieRatings ratings, int userId, int movieId)
    {
        double userRating = this.predictSimilarUserRating(ratings, userId, movieId);
        double movieRating = this.predictSimilarMovieRating(ratings, userId, movieId);
        
        // Only valid ratings should be count.
        double rating;
        if(userRating < 0)
        {
            if(movieRating < 0)
            {
                // Use 3 if no valid rating at all.
                rating = 3;
            }else
            {
                rating = movieRating;
            }
        }else
        {
            if(movieId < 0)
            {
                rating = userRating;
            }else
            {
                rating = (movieRating + userRating)/2;
            }
        }
        return (int) Math.round(rating + .5);
    }
    
    /**
     * Predict the rating according to similar users.
     * @param ratings
     * @param userId
     * @param movieId
     * @return
     */
    private double predictSimilarUserRating(MovieRatings ratings, int userId, int movieId)
    {
        // Go over all the ratings of the same movie from the other users.
        TreeMap<Double, Integer> similarityToRatingMap = new TreeMap<>();
        for(int userId2 = 1;userId2 <= ratings.getMaxUserId();userId2++)
        {
            User user = userMap.get(userId);
            User user2 = userMap.get(userId2);
            if(user == null|| user2 == null|| userId2 == userId)
            {
                continue;
            }
            
            Rating rating2 = ratings.get(userId2, movieId);
            if(rating2 == null)
            {
                // Do not take empty ratings into consideration.
                continue;
            }
            
            // Check and keep the top k similarities.
            double similarity = this.getSimilarity(ratings, user, user2);
            similarityToRatingMap.put(similarity, rating2.getRating());
            if(similarityToRatingMap.size() > k)
            {
                similarityToRatingMap.pollFirstEntry();
            }
        }
        
        // Invalid prediction if there's no similar items.
        if(similarityToRatingMap.isEmpty())
        {
            return -1;
        }
        
        int ratingSum = 0;
        for(Integer rating2 : similarityToRatingMap.values())
        {
            ratingSum += rating2;
        }
        double estimatedRating = ratingSum / (double) similarityToRatingMap.size();
        return estimatedRating;
    }
    
    /**
     * Predict the rating according to similar movies.
     * @param ratings
     * @param userId
     * @param movieId
     * @return
     */
    private double predictSimilarMovieRating(MovieRatings ratings, int userId, int movieId)
    {
        // Go over all the ratings of the other movies from the same user.
        TreeMap<Double, Integer> similarityToRatingMap = new TreeMap<>();
        for(int movieId2 = 1;movieId2 <= ratings.getMaxMovieId();movieId2++)
        {
            Movie movie = movieMap.get(movieId);
            Movie movie2 = movieMap.get(movieId2);
            if(movie == null|| movie2 == null|| movieId2 == movieId)
            {
                continue;
            }
            
            Rating rating2 = ratings.get(movieId2, movieId);
            if(rating2 == null)
            {
                // Do not take empty ratings into consideration.
                continue;
            }

            // Check and keep the top k similarities.
            double similarity = this.getSimilarity(ratings, movie, movie2);
            similarityToRatingMap.put(similarity, rating2.getRating());
            if(similarityToRatingMap.size() > k)
            {
                similarityToRatingMap.pollFirstEntry();
            }
        }
        
        // Invalid prediction if there's no similar items.
        if(similarityToRatingMap.isEmpty())
        {
            return -1;
        }
        
        int ratingSum = 0;
        for(Integer rating2 : similarityToRatingMap.values())
        {
            ratingSum += rating2;
        }
        double estimatedRating = ratingSum / (double) similarityToRatingMap.size();
        return estimatedRating;
    }
    
    /**
     * Calculate the similarity between the two movies.
     * @param ratings
     * @param movie1
     * @param movie2
     * @return
     */
    private double getSimilarity(MovieRatings ratings, Movie movie1, Movie movie2)
    {
        int movieId1 = movie1.getId();
        int movieId2 = movie2.getId();
        int userId1 = ratings.nextUserId(-1, movieId1);
        int userId2 = ratings.nextUserId(-1, movieId2);
        double similaritySum = 0;
        int similarityNumber = 0;
        // Go over all the common users and compare their ratings.
        while(userId1 >= 0&& userId2 >= 0)
        {
            if(userId1 < userId2)
            {
                userId1 = ratings.nextUserId(userId1, movieId1);
                continue;
            }
            if(userId1 > userId2)
            {
                userId2 = ratings.nextUserId(userId2, movieId2);
                continue;
            }
            
            // The similarity depends on the difference of their ratings.
            int rating1 = ratings.get(userId1, movieId1).getRating();
            int rating2 = ratings.get(userId2, movieId2).getRating();
            similaritySum += 1 - Math.abs(rating1 - rating2) / 4d;
            similarityNumber++;
            userId1 = ratings.nextUserId(userId1, movieId1);
        }
        
        if(similarityNumber > 0)
        {
            return similaritySum / similarityNumber;
        }else
        {
            return 0;
        }
    }

    /**
     * Calculate the similarity between the two users.
     * @param ratings
     * @param user1
     * @param user2
     * @return
     */
    private double getSimilarity(MovieRatings ratings, User user1, User user2)
    {
        int userId1 = user1.getId();
        int userId2 = user2.getId();
        int movieId1 = ratings.nextMovieId(userId1, -1);
        int movieId2 = ratings.nextMovieId(userId2, -1);
        double similaritySum = 0;
        int similarityNumber = 0;
        // Go over all the common movies and compare their ratings.
        while(movieId1 >= 0&& movieId2 >= 0)
        {
            if(movieId1 < movieId2)
            {
                movieId1 = ratings.nextMovieId(userId1, movieId1);
                continue;
            }
            if(movieId1 > movieId2)
            {
                movieId2 = ratings.nextMovieId(userId2, movieId2);
                continue;
            }

            // The similarity depends on the difference of their ratings.
            int rating1 = ratings.get(userId1, movieId1).getRating();
            int rating2 = ratings.get(userId2, movieId2).getRating();
            similaritySum += 1 - Math.abs(rating1 - rating2) / 4d;
            similarityNumber++;
            movieId1 = ratings.nextMovieId(userId1, movieId1);
        }
        
        if(similarityNumber > 0)
        {
            return similaritySum / similarityNumber;
        }else
        {
            return 0;
        }
    }
}
