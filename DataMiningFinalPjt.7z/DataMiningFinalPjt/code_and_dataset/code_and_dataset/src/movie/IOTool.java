package movie;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import movie.model.Gender;
import movie.model.Genre;
import movie.model.Movie;
import movie.model.MovieRatings;
import movie.model.Rating;
import movie.model.User;

public class IOTool
{
    public static final DateFormat DATE_FORMAT = new SimpleDateFormat("dd-MMM-yyyy");
    
    private IOTool()
    {
        
    }
    
    public static List<User> readUsers(String path)
    {
        try(Scanner scanner = new Scanner(new File(path)))
        {
            List<User> users = new LinkedList<>();
            
            while(scanner.hasNextLine())
            {
                String line  = scanner.nextLine().trim();
                if(line.length() == 0)
                {
                    continue;
                }
                
                String[] fragments = line.split("\\|");
                
                User user = new User();
                users.add(user);
                user.setId(Integer.parseInt(fragments[0]));
                user.setAge(Integer.parseInt(fragments[1]));
                user.setGender(fragments[2].equals("M") ? Gender.MALE : Gender.FEMALE);
                user.setOccupation(fragments[3]);
                user.setZipCode(fragments[4]);
            }
            
            return users;
        }catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }
    
    public static List<Genre> readGenres(String path)
    {
        try(Scanner scanner = new Scanner(new File(path)))
        {
            List<Genre> genres = new LinkedList<>();
            
            while(scanner.hasNextLine())
            {
                String line  = scanner.nextLine().trim();
                if(line.length() == 0)
                {
                    continue;
                }
                
                String[] fragments = line.split("\\|");

                Genre genre = new Genre();
                genres.add(genre);
                genre.setName(fragments[0]);
                genre.setId(Integer.parseInt(fragments[1]));
            }
            
            return genres;
        }catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }
    
    public static List<Movie> readMovies(String path, Map<Integer, Genre> genreMap)
    {
        try(Scanner scanner = new Scanner(new File(path)))
        {
            List<Movie> movies = new LinkedList<>();
            
            while(scanner.hasNextLine())
            {
                String line  = scanner.nextLine().trim();
                if(line.length() == 0)
                {
                    continue;
                }
                
                String[] fragments = line.split("\\|");

                Movie movie = new Movie();
                movies.add(movie);
                movie.setId(Integer.parseInt(fragments[0]));
                movie.setTitle(fragments[1]);
                movie.setReleaseDate(parseTimestamp(fragments[2]));
                movie.setVideoReleaseDate(parseTimestamp(fragments[3]));
                List<Genre> genres = movie.getGenres();
                for(int i = 4;i < fragments.length;i++)
                {
                    if(fragments[i].equals("1"))
                    {
                        genres.add(genreMap.get(i - 3));
                    }
                }
            }
            
            return movies;
        }catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }
    
    public static long parseTimestamp(String string)
    {
        try
        {
            return DATE_FORMAT.parse(string).getTime();
        }catch(Exception e)
        {
            return 0;
        }
    }
    
    public static MovieRatings readMovieRatings(String path, Map<Integer, User> userMap, Map<Integer, Movie> movieMap)
    {
        try(Scanner scanner = new Scanner(new File(path)))
        {
            MovieRatings ratings = new MovieRatings();
            
            while(scanner.hasNextLine())
            {
                String line  = scanner.nextLine().trim();
                if(line.length() == 0)
                {
                    continue;
                }
                
                String[] fragments = line.split("[ \\t]");
                
                Rating rating = new Rating();
                int userId = Integer.parseInt(fragments[0]);
                rating.setUser(userMap.get(userId));
                int movieId = Integer.parseInt(fragments[1]);
                rating.setMovie(movieMap.get(movieId));
                rating.setRating(Integer.parseInt(fragments[2]));
                rating.setTimestamp(Long.parseLong(fragments[3]));
                ratings.set(userId, movieId, rating);
            }
            
            return ratings;
        }catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }
}
